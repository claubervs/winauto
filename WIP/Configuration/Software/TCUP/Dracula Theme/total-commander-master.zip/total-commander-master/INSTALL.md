### [Total Commander](https://www.ghisler.com/)

#### Install using Git

If you are a git user, you can install the theme and keep up to date by cloning the repo:

    $ git clone https://github.com/dracula/total-commander.git

#### Install manually

Download using the [GitHub .zip download](https://github.com/dracula/total-commander/archive/master.zip) option and unzip them.

#### Activating theme

1. Copy colors.ini in X:\Users\ *username* \AppData\Roaming\GHISLER
