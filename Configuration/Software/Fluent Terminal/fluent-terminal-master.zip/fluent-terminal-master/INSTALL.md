### [Fluent Terminal](https://github.com/felixse/FluentTerminal)

#### Install

Download using the [GitHub .zip download](https://github.com/dracula/fluent-terminal/archive/master.zip) option and unzip them.

#### Activating theme

Go to `Settings > Themes` and import the file `Dracula.flutecolors`.