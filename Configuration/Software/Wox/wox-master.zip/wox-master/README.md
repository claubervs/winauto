# Dracula for [Wox](https://github.com/Wox-launcher/Wox)

> A dark theme for [Wox](https://github.com/Wox-launcher/Wox).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/wox](https://draculatheme.com/wox).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/wox/graphs/contributors).

[![Kevin Darlington](https://avatars3.githubusercontent.com/u/119919?v=3&s=70)](https://github.com/kdar) |
--- |
[Kevin Darlington](https://github.com/kdar) |

## License

[MIT License](./LICENSE)
